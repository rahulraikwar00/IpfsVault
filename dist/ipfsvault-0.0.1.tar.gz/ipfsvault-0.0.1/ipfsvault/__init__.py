"""

Ipfsvault

decentralize storage for authenticatino process package it uses ipfs for storing the data and multihash, md5, sha256, sha512 for authentication.
"""

__version__ = "0.0.1"
__author__ = 'Rahul Raikwar'
__credits__ = 'Argonne National Laboratory'